param([switch]$NoBrowser)
# Windows PowerShell 5.1. Loopback-only HTTP transport; no PLC control logic.
$ErrorActionPreference = 'Stop'
$port = 8765
$webRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\web'))
$inputs = @{ Start='0'; StopOK='0'; OverloadOK='1'; FrameId='0' }
$status = $null
$lastWinCC = [DateTime]::MinValue
$files = @{ '/bridge/index.html'='index.html'; '/bridge/plant.css'='plant.css'; '/bridge/plant.js'='plant.js'; '/bridge/protocol.js'='protocol.js' }
function Parse-Form([string]$body) {
    $form = @{}
    foreach ($part in $body.Split('&')) {
        $pair = $part -split '=',2
        if ($pair.Count -ne 2) { throw 'Bad form' }
        $key = [Uri]::UnescapeDataString($pair[0].Replace('+',' '))
        $value = [Uri]::UnescapeDataString($pair[1].Replace('+',' '))
        if ($form.ContainsKey($key)) { throw 'Duplicate field' }
        $form[$key] = $value
    }
    return $form
}
function Write-Reply($stream,[int]$code,[string]$type,[byte[]]$data) {
    $head = "HTTP/1.1 $code Response`r`nContent-Type: $type`r`nContent-Length: $($data.Length)`r`nCache-Control: no-store`r`nConnection: close`r`nX-Frame-Options: DENY`r`nX-Content-Type-Options: nosniff`r`n`r`n"
    $bytes = [Text.Encoding]::ASCII.GetBytes($head)
    $stream.Write($bytes,0,$bytes.Length)
    $stream.Write($data,0,$data.Length)
    $stream.Flush()
}
function Text-Reply($stream,[int]$code,[string]$body) {
    Write-Reply $stream $code 'text/plain; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($body))
}
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$port)
try {
    $listener.Start()
    Write-Host 'PLC Lab bridge: http://127.0.0.1:8765/bridge/index.html'
    Write-Host 'Start PLCSIM + WinCC RT Advanced, with LabExchange triggered by Lab_Tick value changes.'
    Write-Host 'Close this window to end the bridge. No software is installed.'
    if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:8765/bridge/index.html' }
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $stream.ReadTimeout = 2000
        $stream.WriteTimeout = 2000
        try {
            $header = [Collections.Generic.List[byte]]::new()
            while ($header.Count -lt 16384) {
                $next = $stream.ReadByte()
                if ($next -lt 0) { throw 'Closed connection' }
                $header.Add([byte]$next)
                $n=$header.Count
                if ($n -ge 4 -and $header[$n-4] -eq 13 -and $header[$n-3] -eq 10 -and $header[$n-2] -eq 13 -and $header[$n-1] -eq 10) { break }
            }
            if ($header.Count -ge 16384) { throw 'Header too large' }
            $lines = ([Text.Encoding]::ASCII.GetString($header.ToArray())) -split "`r`n"
            $request = $lines[0].Split(' ')
            if ($request.Count -ne 3) { throw 'Bad request' }
            $method=$request[0]; $path=($request[1].Split('?'))[0]
            $headers=@{}
            foreach ($line in $lines | Select-Object -Skip 1) {
                $colon=$line.IndexOf(':')
                if ($colon -gt 0) { $headers[$line.Substring(0,$colon).ToLowerInvariant()]=$line.Substring($colon+1).Trim() }
            }
            if ($headers['host'] -ne "127.0.0.1:$port") { Text-Reply $stream 403 'Use the loopback URL printed by this bridge.'; continue }
            if ($headers.ContainsKey('origin') -and $headers['origin'] -ne "http://127.0.0.1:$port") { Text-Reply $stream 403 'Origin rejected'; continue }
            $length=0
            if ($headers.ContainsKey('content-length')) { if ($headers['content-length'] -notmatch '^\d{1,4}$') { throw 'Bad length' }; $length=[int]$headers['content-length'] }
            if ($length -gt 4096 -or $headers.ContainsKey('transfer-encoding')) { throw 'Unsupported body' }
            $bodyBytes=New-Object byte[] $length; $offset=0
            while ($offset -lt $length) { $read=$stream.Read($bodyBytes,$offset,$length-$offset); if ($read -le 0) { throw 'Incomplete body' }; $offset+=$read }
            $body=[Text.Encoding]::UTF8.GetString($bodyBytes)
            if ($method -eq 'GET' -and $files.ContainsKey($path)) {
                $file=$files[$path]; $type=if ($file.EndsWith('.css')) {'text/css'} elseif ($file.EndsWith('.js')) {'application/javascript'} else {'text/html; charset=utf-8'}
                Write-Reply $stream 200 $type ([IO.File]::ReadAllBytes((Join-Path $webRoot $file)))
            } elseif ($method -eq 'POST' -and $path -eq '/bridge/io.htm') {
                $form=Parse-Form $body
                if ($form.Count -ne 4) { throw 'Expected four input fields' }
                $nextInputs=@{}
                foreach ($key in @('Start','StopOK','OverloadOK','FrameId')) {
                    $v=$form['"DB_StartPlant".'+$key]
                    if ($key -eq 'FrameId') { if ($v -notmatch '^\d{1,5}$' -or [int]$v -gt 65535) { throw 'Bad frame id' } }
                    elseif ($v -notmatch '^[01]$') { throw 'Bad input bit' }
                    $nextInputs[$key]=$v
                }
                $inputs=$nextInputs
                Text-Reply $stream 200 'Accepted; awaiting PLC acknowledgement'
            } elseif ($method -eq 'GET' -and $path -eq '/bridge/io.htm') {
                if ($null -eq $status -or ([DateTime]::UtcNow-$lastWinCC).TotalSeconds -gt 4) { Text-Reply $stream 503 'WinCC exchange is absent or stale. Check Runtime and LabExchange task.' }
                else { Text-Reply $stream 200 $status }
            } elseif ($method -eq 'POST' -and $path -eq '/wincc/exchange') {
                $form=Parse-Form $body
                if ($form.Count -ne 5) { throw 'Bad HMI response' }
                foreach ($key in @('Start','StopOK','OverloadOK','MotorCommand')) { if ($form[$key] -notmatch '^[01]$') { throw 'Bad HMI bit' } }
                if ($form['Ack'] -notmatch '^\d{1,5}$' -or [int]$form['Ack'] -gt 65535) { throw 'Bad HMI acknowledgement' }
                $status=(@('Start','StopOK','OverloadOK','MotorCommand','Ack') | ForEach-Object { $_+'='+$form[$_] }) -join "`n"
                $lastWinCC=[DateTime]::UtcNow
                $command=(@('Start','StopOK','OverloadOK','FrameId') | ForEach-Object { $_+'='+$inputs[$_] }) -join "`n"
                Text-Reply $stream 200 $command
            } else { Text-Reply $stream 404 'Not found' }
        } catch {
            try { Text-Reply $stream 400 'Invalid bridge request or unavailable local file.' } catch {}
            Write-Host ('Request failed: '+$_.Exception.Message)
        } finally { $stream.Dispose(); $client.Dispose() }
    }
} finally { $listener.Stop() }

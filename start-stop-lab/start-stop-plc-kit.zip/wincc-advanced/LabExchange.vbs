Sub LabExchange()
' PC Runtime Advanced only. Call from the Value change event of external tag Lab_Tick (100 ms continuous acquisition).
' No PLC control logic here. Motor and Ack are read from external HMI tags.
Dim req, data, reply, lines, line, pair, cmd
On Error Resume Next
Set cmd = CreateObject("Scripting.Dictionary")
data = "Start=" & CStr(Abs(CInt(SmartTags("Lab_StartEcho")))) & _
       "&StopOK=" & CStr(Abs(CInt(SmartTags("Lab_StopOKEcho")))) & _
       "&OverloadOK=" & CStr(Abs(CInt(SmartTags("Lab_OverloadOKEcho")))) & _
       "&MotorCommand=" & CStr(Abs(CInt(SmartTags("Lab_MotorCommand")))) & _
       "&Ack=" & CStr(CLng(SmartTags("Lab_Ack")))
If Err.Number <> 0 Then
    ShowSystemAlarm "PLC Lab: HMI tag read failed. Check external tag names."
    Exit Sub
End If
Set req = CreateObject("WinHttp.WinHttpRequest.5.1")
req.SetTimeouts 300, 300, 300, 500
req.Open "POST", "http://127.0.0.1:8765/wincc/exchange", False
req.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
req.Send data
If Err.Number <> 0 Then
    Exit Sub
End If
If req.Status <> 200 Then
    ShowSystemAlarm "PLC Lab: local bridge rejected the HMI exchange."
    Exit Sub
End If
reply = req.ResponseText
lines = Split(Replace(reply, vbCr, ""), vbLf)
For Each line In lines
    pair = Split(line, "=", 2)
    If UBound(pair) = 1 Then cmd(pair(0)) = Trim(pair(1))
Next
If Not cmd.Exists("FrameId") Or Not cmd.Exists("Start") Or Not cmd.Exists("StopOK") Or Not cmd.Exists("OverloadOK") Then
    ShowSystemAlarm "PLC Lab: incomplete command frame."
    Exit Sub
End If
If (cmd("Start") <> "0" And cmd("Start") <> "1") Or (cmd("StopOK") <> "0" And cmd("StopOK") <> "1") Or (cmd("OverloadOK") <> "0" And cmd("OverloadOK") <> "1") Then Exit Sub
If Not IsNumeric(cmd("FrameId")) Then Exit Sub
If CLng(cmd("FrameId")) < 0 Or CLng(cmd("FrameId")) > 65535 Then Exit Sub
' The four browser-owned values are the only writes. Never write Lab_MotorCommand/Ack/Echo.
SmartTags("Lab_Start") = CBool(CInt(cmd("Start")))
SmartTags("Lab_StopOK") = CBool(CInt(cmd("StopOK")))
SmartTags("Lab_OverloadOK") = CBool(CInt(cmd("OverloadOK")))
SmartTags("Lab_FrameId") = CLng(cmd("FrameId"))
If Err.Number <> 0 Then ShowSystemAlarm "PLC Lab: external tag write failed."
Set req = Nothing
Set cmd = Nothing
End Sub

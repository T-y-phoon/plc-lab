# Teacher preflight on Windows. Simulates only the HMI exchange, not a Siemens PLC.
$ErrorActionPreference='Stop'
$process=$null
function Assert-True($value,$label) { if (-not $value) { throw $label } }
function Post-Data($path,$data) { Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:8765'+$path) -Method Post -Body $data -TimeoutSec 5 }
try {
    $script=Join-Path $PSScriptRoot 'Start-Bridge.ps1'
    $process=Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$script+'"'),'-NoBrowser') -PassThru
    Start-Sleep -Seconds 1
    $page=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/bridge/index.html' -TimeoutSec 5
    Assert-True ($page.StatusCode -eq 200) 'Static page did not load'
    $initial=@{Start='0';StopOK='0';OverloadOK='1';MotorCommand='0';Ack='0'}
    $reply=Post-Data '/wincc/exchange' $initial
    Assert-True ($reply.Content -match 'FrameId=0') 'Initial frame is missing'
    $command=@{ '"DB_StartPlant".Start'='1'; '"DB_StartPlant".StopOK'='0'; '"DB_StartPlant".OverloadOK'='1'; '"DB_StartPlant".FrameId'='1' }
    $null=Post-Data '/bridge/io.htm' $command
    $reply=Post-Data '/wincc/exchange' $initial
    Assert-True ($reply.Content -match 'Start=1') 'Browser command not sent to HMI'
    Assert-True ($reply.Content -match 'FrameId=1') 'Frame id not sent to HMI'
    $feedback=@{Start='1';StopOK='0';OverloadOK='1';MotorCommand='1';Ack='1'}
    $null=Post-Data '/wincc/exchange' $feedback
    $read=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/bridge/io.htm' -TimeoutSec 5
    Assert-True ($read.Content -match 'MotorCommand=1') 'Bridge masked the deliberately wrong PLC command'
    Assert-True ($read.Content -match 'Ack=1') 'PLC acknowledgement was lost'
    $bad=@{ '"DB_StartPlant".MotorCommand'='1' }
    $rejected=$false
    try { $null=Post-Data '/bridge/io.htm' $bad } catch { $rejected=($_.Exception.Response.StatusCode.value__ -eq 400) }
    Assert-True $rejected 'Browser output write was not rejected'
    Write-Host 'PASS: Windows bridge HTTP, HMI exchange, frame/feedback direction and output-write rejection.'
    Write-Host 'This does NOT validate WinCC COM, TIA compilation or Siemens PLC communication.'
} finally { if ($process -and -not $process.HasExited) { Stop-Process -Id $process.Id } }
